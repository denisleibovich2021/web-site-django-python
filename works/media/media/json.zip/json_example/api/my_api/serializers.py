from rest_framework import serializers
from .models import student

class ApiSerializer(serializers.ModelSerializer):
    class Meta:
        model = student
        fields = ['id','name','age','member','grade']