from django.shortcuts import render
from rest_framework import viewsets, permissions
from .models import student
from .serializers import ApiSerializer
# Create your views here.
class ApiView(viewsets.ModelViewSet):
    queryset = student.objects.all()
    serializer_class = ApiSerializer
    #permission_classes = (permissions.IsAuthenticated)
