import json_file

pepole_srting = '''
{
    "people" : [
    
        {
        "name": "Jogn",
        "phone":"123542",
        "email":"denis@gmail.com",
        "license": false
        },
        
        {
        "name": "bob",
        "phone":"788888",
        "email":"kik@gmail.com",
        "license": true
        }

                ]
}
'''

data = json.loads(pepole_srting)
# for person in data["people"]:
#     del person["phone"]
new_string = json.dumps(data, indent=2)
print(new_string)