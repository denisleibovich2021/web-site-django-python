import requests
import json

url = "http://127.0.0.1:8000/my_api/"

payload = json.dumps({
  "name": "CSHELL",
  "paradigm": "shell"
})
headers = {
  'Authorization': 'Basic ZGVuaXM6ZGVuaXMxOTk0',
  'Content-Type': 'application/json'
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)
