
# 1) question == --> Create a JSON file with the information of students the fields will hold the following information.
# Name <string>, age: <integer>, member :< Boolean>. Make sure that you have at least 3 students added to your JSON file.

# import json
# students = '''
#     {
#         "people": [
#                 {
#                 "Name":"denis",
#                 "age":"28",
#                 "member":true
#                 },
#
#                 {
#                 "Name":"levana",
#                 "age":"27",
#                 "member":true
#                 },
#
#                 {
#                 "Name":"vera",
#                 "age":"47",
#                 "member":false
#                  }
#         ]
#     }'''
# data1 = json.loads(students)
# print(data1)

# ========================================================================================================================
# ========================================================================================================================
# ========================================================================================================================
# 2) question == -->  Read your JSON file into python object. Calculate the average age of the students from
# the python object that you created. Update the member value to true for all students that their age is higher than 18.
# Write the updated dictionary into a new JSON file.

import json
students = '''
    {
        "people": [
                {
                "Name":"denis",
                "age":"28",
                "member":true
                },

                {
                "Name":"levana",
                "age":"27",
                "member":true
                },

                {
                "Name":"vera",
                "age":"47",
                "member":false
                 }
        ]
    }'''

data = json.loads(students)
print(data)
x = 0
for i in data['people']:
    x += int(i['age'])
print('average is ',x)
for i in data['people']:
    if i['age'] >= '18':
        i['member'] = True
with open("update.json","w") as file:
    json.dump(data,file,indent=2)
# ========================================================================================================================
# ========================================================================================================================
# ========================================================================================================================
#
# 3) question == -->  Create Django rest application with a model that is called student the model will hold the
# information of students with fields of name, age, member, and grade. Add at least two students from your Django
# application and add at least two students from postman application as well
