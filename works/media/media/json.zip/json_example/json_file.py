import json
with open("people.json") as file:
    data = json.load(file)



print(data)
for person in data["people"]:
    del person["phone"]
with open("new_people.json","w") as file:
    json.dump(data,file, indent=2)