from django.db import models

class Ex10db(models.Model):
    country_name = models.CharField(max_length=20)
    capital_city = models.CharField(max_length=20)
    population = models.IntegerField()

    def __str__(self):
        return self.country_name