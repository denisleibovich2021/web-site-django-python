from django.contrib import admin

from .models import Ex10db
admin.site.register(Ex10db)
