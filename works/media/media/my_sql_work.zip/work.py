
# 1) question : Establish a connection between MySQL and python.
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================
# import mysql.connector
# mydb = mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='denis1994',
#
# )





# 2) question : Create a database called ex10db. Check that the database that was created with a relevant command
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================
# import mysql.connector
# mydb = mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='denis1994',
#
# )
# mycursor = mydb.cursor()
# mycursor.execute("CREATE DATABASE ex10db")
# mycursor.execute("SHOW DATABASES")
# for db in mycursor:
#     print(db)






# 3) question : Create a table with the following three fields that will describe a country, capital city that will
# receive a string value, population size that will receive an integer value and the name of the country that will
# receive a string value. Make sure that the table that we created. Make sure that you can see your database and its
# table in MySQL workbench.
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================
# import mysql.connector
# mydb = mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='denis1994',
#     database='ex10db'
#
# )
# mycursor = mydb.cursor()
# mycursor.execute("CREATE TABLE country (country_name VARCHAR(50),capital_city VARCHAR(50),population INT(50))")
# mycursor.execute("SHOW DATABASES")
# for db in mycursor:
#     print(db)






# 4) question : Create an SQL formula that will be able to add data to your table and add at least 4 different
# countries' data to your table. Make sure that you see the updated results in the workbench as well.
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================
# import mysql.connector
# mydb = mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='denis1994',
#     database='ex10db'
#
# )
# mycursor = mydb.cursor()
# sqlFormula = "INSERT INTO country (country_name,capital_city,population) VALUES (%s,%s,%s)"
# country= [('China','Beijing',1412600000),('Egypt','Cairo',102300000),('Israel','Jerusalem',9217000),('Czech Republic','Prague', 107000000)]
# mycursor.executemany(sqlFormula,country)
# mydb.commit()





# 5) question : Print just the capital cities of countries that their name is starting from the letter I into a text file.
# Try to check it out with different content of data in your table.
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================
# import mysql.connector
# mydb = mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='denis1994',
#     database='ex10db'
#
# )
# mycursor = mydb.cursor()
# mycursor.execute("SELECT capital_city FROM country WHERE country_name Like 'I%' ")
# myresult = mycursor.fetchall()
# for row in myresult:
#     print(row)








# 6) question : Update the population size to 10,000 for each country that it’s capital city name ends
# with the letters “o”. Try to check it out with different content of data in your table.
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================
# import mysql.connector
# mydb = mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='denis1994',
#     database='ex10db'
#
# )
# mycursor = mydb.cursor()
# mycursor.execute("UPDATE country SET population=10000 WHERE capital_city Like '%o' ")
# mydb.commit()





# 7) question : Write your countries into a text file in descending order base on the country’s population.
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================
# import mysql.connector
# mydb = mysql.connector.connect(
#     host='localhost',
#     user='root',
#     password='denis1994',
#     database='ex10db'
#
# )
# file = open("file.txt","w")
# mycursor = mydb.cursor()
# mycursor.execute("SELECT * FROM country ORDER BY population DESC")
# myresult = mycursor.fetchall()
# for row in myresult:
#     row_str = str(row)
#     file.write(row_str+'\n')







# 8) question : Create a Django project, whatever you want, and please establish the connection to the MySQL database.
# Make sure that you can create a table from your Django application to your MySQL database. Commit some data to
# your table straightly from the MySQL workbench and the admin application as well.
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================

# in a PycharmProjects/hm10sql/mysql_project
