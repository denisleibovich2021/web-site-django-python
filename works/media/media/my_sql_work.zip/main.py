import mysql.connector
mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password='denis1994',
    database='ex10db'

)